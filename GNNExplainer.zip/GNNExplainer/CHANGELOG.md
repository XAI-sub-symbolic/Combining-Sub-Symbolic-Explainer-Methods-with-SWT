# Changelog

## v`0.0.1`
---

> 23 May 2019

- Paper submitted
- Experiments complete

> 04 September 2019

- Paper accepted